"""Phases 5-6 - baselines and deep models (not built yet).

Planned: Altman Z'' threshold, logistic regression, XGBoost; GatedFusionNet (FinBERT + BiGRU
attention, linguistic MLP, ratio MLP, gated fusion, adversarial business-group head), temporal
drift variant, Word2Vec + 1D-CNN comparison. 5-fold GroupKFold by company. See docs/00_project_plan.md.
"""
